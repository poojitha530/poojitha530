from django.shortcuts import render, redirect
from .models import Order, Asset

def place_order(request):
    if request.method == 'POST':
        asset_id = request.POST.get('asset_id')
        order_type = request.POST.get('order_type')
        price = request.POST.get('price')
        quantity = request.POST.get('quantity')

        # Ensure the asset exists before creating the order
        try:
            asset = Asset.objects.get(id=asset_id)
        except Asset.DoesNotExist:
            return render(request, 'place_order.html', {
                'error': 'Selected asset does not exist.',
                'assets': Asset.objects.all()
            })

        # Create the order
        Order.objects.create(
            asset=asset,
            order_type=order_type,
            price=price,
            quantity=quantity,
        )
        
        return redirect('orders')  # Replace 'orders' with the actual name of your orders view or URL pattern

    # For GET request, render the form with a list of assets
    assets = Asset.objects.all()
    return render(request, 'place_order.html', {'assets': assets})


def add_to_watchlist(request):
    if request.method == 'POST':
        asset = Asset.objects.get(id=request.POST['asset_id'])
        quantity = request.POST['quantity']
        currency_type = request.POST['currency_type']
        
        # Create or update the watchlist entry
        Watchlist.objects.create(
            asset=asset,
            quantity=quantity,
            currency_type=currency_type,
        )
        
        return redirect('view_watchlist')  # Redirect to the watchlist display page

    # If GET request, display the add form
    assets = Asset.objects.all()
    return render(request, 'add_to_watchlist.html', {'assets': assets})

from django.shortcuts import render
from .models import Watchlist

def view_watchlist(request):
    watchlist = Watchlist.objects.all()
    return render(request, 'watchlist.html', {'watchlist': watchlist})

