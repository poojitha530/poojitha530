from django.urls import path
from . import views

urlpatterns = [
    path('add_to_watchlist/', views.add_to_watchlist, name='add_to_watchlist'),
    path('watchlist/', views.view_watchlist, name='view_watchlist'),
    path('place_order/', views.place_order, name='place_order')
]

