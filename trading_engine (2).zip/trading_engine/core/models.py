#from django.db import models

from django.db import models

class Asset(models.Model):
    name = models.CharField(max_length=50)
    symbol = models.CharField(max_length=10)

class Order(models.Model):
    asset = models.ForeignKey(Asset, on_delete=models.CASCADE)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    quantity = models.DecimalField(max_digits=10, decimal_places=2)
    order_type = models.CharField(max_length=4, choices=(("buy", "Buy"), ("sell", "Sell")))
    created_at = models.DateTimeField(auto_now_add=True)



class Watchlist(models.Model):
    asset = models.ForeignKey(Asset, on_delete=models.CASCADE)
    quantity = models.DecimalField(max_digits=10, decimal_places=2)
    currency_type = models.CharField(max_length=10)

