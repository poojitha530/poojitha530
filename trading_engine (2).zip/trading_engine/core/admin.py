from django.contrib import admin
from .models import Asset, Order, Watchlist

@admin.register(Asset)
class AssetAdmin(admin.ModelAdmin):
    list_display = ('name', 'symbol')
    search_fields = ('name', 'symbol')

@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('asset', 'order_type', 'price', 'quantity', 'created_at')
    list_filter = ('order_type', 'created_at')
    search_fields = ('asset__name', 'asset__symbol')
    date_hierarchy = 'created_at'

@admin.register(Watchlist)
class WatchlistAdmin(admin.ModelAdmin):
    list_display = ('asset', 'quantity', 'currency_type')
    search_fields = ('asset__name', 'asset__symbol', 'currency_type')
